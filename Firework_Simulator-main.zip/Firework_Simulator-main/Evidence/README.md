# 目前已道歉

# 此文件是专门给“[小俊](https://github.com/laulzgoay)”看的，如果你不是“小俊”可以无视此文件

直接把我的项目下载下来，改个名字就成你自己的东西了？

如果我是机翻 那么你盗取我的成果 我也不会说你什么

可我是**人工翻译** 你还盗取 你这种人让我觉得恶心

人工翻译你还翻译的跟我一模一样？

真没想到在Github也能遇到你这种人 你如果不会汉化可以不要汉化

下载我的项目，把“碎念”改成“小俊”就是你的东西了？

------

### 以下为证据

#### 证据1：

![](https://cdn.jsdelivr.net/gh/NianBroken/Firework_Simulator/Evidence/01.png)

- 在项目的`\js\script.js`的第312行开始，你翻译的跟我一模一样？

- 我这是**人工翻译**呀，而且我很多翻译完全跟原本是英文句子对不上意思

- 我的翻译是为了让更多人能理解那个功能的作用

- 例如：

- > Launches intense bursts of fireworks. May cause lag. Requires "Auto Fire" to be enabled.

- 我翻译为：

- > 可以在同一时间自动放出更多的烟花（但需要开启先开启“自动放烟花”）。

- 再例如：

- > FINALE MODE

- 我翻译为

- > 同时放更多的烟花

- 小俊您可真厉害呀，想的跟我一样！

#### 证据2：

- 在项目的`\js\script.js`的第325行我有一个文字翻译错误

- > 可以把它改成“暗”或者“无”。

![](https://cdn.jsdelivr.net/gh/NianBroken/Firework_Simulator/Evidence/02.png)

- 这里应该把”无“翻译为”不“ 因为在`\js\script.js`的第838行我翻译为了”不“

![](https://cdn.jsdelivr.net/gh/NianBroken/Firework_Simulator/Evidence/03.png)

- **你错都跟我错的一样？那您还真是厉害呀！**

#### 证据3：

![](https://cdn.jsdelivr.net/gh/NianBroken/Firework_Simulator/Evidence/04.png)

- 在项目的`index.html`的第212行

- > 希望你所有的不开心 都可以在本站的声声烟花声中结束

- 原文案为

- > 希望你所有的不幸 都可以在本站的声声鞭炮中结束

- **这抄的太明显了吧？这个文案可是我自己想出来的，难道你也想的跟我一样？**
